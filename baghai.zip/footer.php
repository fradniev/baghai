		<footer>
			<div class="row valign-wrapper">
				<div class="col s5" style="margin-left: 0 !important">
					<div class="row">
						<div class="col s12 footer">
							<p>2016. Baghai Digital.All right reserved</p>
						</div>
					</div>
				</div>
				<div class="col s6 right-align logos-social" >
					<img style="width: 2%; margin-right: 15px" src="<?php echo get_template_directory_uri() . '/images/logos partnes/instagram.png'; ?>">
					<img style="width: 2%; margin-right: 15px" src="<?php echo get_template_directory_uri() . '/images/logos partnes/facebook.png'; ?>">
					<img style="width: 2%;" src="<?php echo get_template_directory_uri() . '/images/logos partnes/twitter.png'; ?>">
				</div>
			</div>
		</footer>
		<?php wp_footer(); ?>
	</body>
</html>